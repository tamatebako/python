# fixture getpath.py stub (runtime prefix resolution)
